from .ffi import IN_BROWSER

__all__ = ["IN_BROWSER"]
